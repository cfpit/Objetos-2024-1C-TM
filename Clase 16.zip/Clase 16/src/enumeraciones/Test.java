package enumeraciones;

import java.util.Scanner;


public class Test {
    public static void main(String[] args) {
        Scanner lector = new Scanner(System.in);
        System.out.println("Ingresa el dia de hoy: ");
        String diaHoy = lector.next();
        
        if (diaHoy.toLowerCase().equals(String.valueOf(Dia.LUNES).toLowerCase())) 
        {
            System.out.println("Hoy arranca la semana!");
        } 
        else 
        {
            if (diaHoy.toLowerCase().equals(String.valueOf(Dia.VIERNES).toLowerCase())) 
            {
                System.out.println("Se viene el finde!");
            } 
            else 
            {
                System.out.println("es un dia cualquiera");
            }
        }
    }
}
