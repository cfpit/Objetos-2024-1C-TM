package relaciones1a1;

public class Motor {
    private String tipo;
    private int cilindrada;

    public Motor() {}

    public Motor(String tipo, int cilindrada) {
        this.tipo = tipo;
        this.cilindrada = cilindrada;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getCilindrada() {
        return cilindrada;
    }

    public void setCilindrada(int cilindrada) {
        this.cilindrada = cilindrada;
    }

    @Override
    public String toString() {
        return "Motor{" + "tipo=" + tipo + ", cilindrada=" + cilindrada + '}';
    }
}
