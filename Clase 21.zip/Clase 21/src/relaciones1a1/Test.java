package relaciones1a1;

public class Test {
    public static void main(String[] args) {
        Motor m = new Motor("Diesel", 1600);
        Auto a = new Auto("Ford", "Gris", m);
        
        System.out.println("Auto: " + a);
        
    }
}
