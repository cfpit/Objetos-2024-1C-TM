package relaciones1aN;

import java.util.ArrayList;
import java.util.List;

public class Concesionaria {
    //atributos
    private String nombre;
    private List<Auto> autos;//relacion 1 a N

    public Concesionaria() {}

    public Concesionaria(String nombre) {
        this.nombre = nombre;
        this.autos = new ArrayList();
    }
    
    //metodos delegados
    public boolean agregar(Auto e) {
        return autos.add(e);
    }

    public boolean eliminar(Object o) {
        return autos.remove(o);
    }
    
    //getters y setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public List<Auto> getAutos() {
        return autos;
    }

    public void setAutos(List<Auto> autos) {
        this.autos = autos;
    }

    @Override
    public String toString() {
        return "Concesionaria{" + "nombre=" + nombre + ", autos=" + autos + '}';
    }
}
