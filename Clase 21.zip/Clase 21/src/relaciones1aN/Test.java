package relaciones1aN;

public class Test {
    public static void main(String[] args) {
        Concesionaria c = new Concesionaria("AutoLatina SRL");
        
        Auto a1 = new Auto("Ford", 25);
        Auto a2 = new Auto("Chevrolet", 40);
        Auto a3 = new Auto("Fiat", 0);
        Auto a4 = new Auto("Peugeot", 30);
        
        //agrego los autos en la concesionaria
        c.agregar(a1);
        c.agregar(a2);
        c.agregar(a3);
        c.agregar(a4);
        
        System.out.println(c);
    }
}
