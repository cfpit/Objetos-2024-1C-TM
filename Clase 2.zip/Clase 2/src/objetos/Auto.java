

package objetos;


public class Auto {
    //atributos
    public String marca;
    public String color;
    public int velocidad;

    //constructores
    public Auto() {}
    
    //metodos
    public void acelerar() {
        velocidad += 10;
    }
}
