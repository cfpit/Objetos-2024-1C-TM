package objetos;

public class Test {
    public static void main(String[] args) {
        //creo un objeto
        Auto a = new Auto();
        
        //defino el estado 
        a.marca = "Ford";
        a.color = "Blanco";
        a.velocidad = 0;
        
        a.acelerar();//0-> 10
        a.acelerar();//10-> 20
        a.acelerar();//20-> 30
        a.acelerar();//30-> 40
        
        System.out.println("velocidad = " + a.velocidad + " km./h.");
    }
}
