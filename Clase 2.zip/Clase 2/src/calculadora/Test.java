package calculadora;
    
import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        Scanner lector = new Scanner(System.in);
        
        //ingreso de datos
        System.out.println("n1 = ");
        double n1 = lector.nextDouble();
        
        System.out.println("n2 = ");
        double n2 = lector.nextDouble();
        
        System.out.println("operacion = ");
        String op = lector.next();
        
        double res = 0;
        
        //condicional de seleccion multiple
        switch (op) {
            case "+":
                System.out.println("n1 + n2 = " + res);
                break;
            case "-":
                res = n1 - n2;
                System.out.println("n1 - n2 = " + res);
                break;
            case "*":
                res = n1 * n2;
                System.out.println("n1 * n2 = " + res);
                break;
            case "/":
                if (n2 == 0) 
                {
                    System.out.println("No se puede dividir por cero");
                } 
                else 
                {
                    res = n1 / n2;
                    System.out.println("n1 / n2 = " + res);
                }
                break;
        }
    }
}
