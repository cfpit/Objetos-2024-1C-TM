package repaso;

import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        int [] edades = new int [5];
        
        //variables auxiliares
        int max = 0, total = 0;
        
        for (int i = 0; i < edades.length; i++) {
            System.out.println("Ingrese una edad: ");
            edades[i] = teclado.nextInt();
            
            //acumulo
//            total = total + edades[i];
            total += edades[i];
            
            //mayor
            if (max < edades[i]) {
                max = edades[i];
            }
        }
        
            System.out.println("promedio = " + total/edades.length);
            System.out.println("maximo = " + max);
        
    }
}
