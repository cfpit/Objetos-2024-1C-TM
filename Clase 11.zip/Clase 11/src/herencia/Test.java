package herencia;

public class Test {
    public static void main(String[] args) {
        //creo 2 objetos
        Vehiculo v = new Vehiculo("rojo", 0);
        Avion a = new Avion("abc-123", "blanco", 0);
        Bici b = new Bici("28", "azul", 0);
        
        //comportamiento
        v.acelerar();
        a.acelerar();//por herencia
        b.acelerar();//por herencia
        
        //por herencia
        System.out.println("color del avion: " + a.getColor());
        System.out.println("rodado de la bici: " + b.getRodado());
        
        //veo el estado completo del avion
        System.out.println(a);
        System.out.println("---------------");
        System.out.println(b);
        
    }
}
