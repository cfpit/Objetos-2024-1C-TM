package herencia;

public class Vehiculo {
    //atributos
    private String color;
    private int velocidad;

    //constructores
    public Vehiculo() {}

    public Vehiculo(String color) {
        this.color = color;
    }

    public Vehiculo(String color, int velocidad) {
        this.color = color;
        this.velocidad = velocidad;
    }
    
    
    
    //getters y setters
    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
    
    public int getVelocidad() {
        return velocidad;
    }

    public void setVelocidad(int velocidad) {
        this.velocidad = velocidad;
    }
    
    //metodos
    public void acelerar() {
        this.velocidad += 10;
    }
    
    
    @Override
    public String toString() {
        return "color=" + color + ", velocidad=" + velocidad;
    }

}
