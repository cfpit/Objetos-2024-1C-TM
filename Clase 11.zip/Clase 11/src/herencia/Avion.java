package herencia;

public class Avion extends Vehiculo{
    //atributos
    private String nombre;
    
    //constructores
    public Avion() {}

    public Avion(String nombre, String color, int velocidad) {
        super(color, velocidad);
        this.nombre = nombre;
    }
    
    //getters y setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    //metodos
    @Override
    public String toString() {
        return "Avion{" + super.toString() + " nombre=" + nombre + '}';
    }
}
