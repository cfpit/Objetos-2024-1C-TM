package herencia;

public class Bici extends Vehiculo{
    //atributos
    private String rodado;
    
    //constructores
    public Bici() {}

    public Bici(String rodado, String color, int velocidad) {
        super(color, velocidad);
        this.rodado = rodado;
    }
    
    //getters y setters
    public String getRodado() {
        return rodado;
    }

    public void setRodado(String rodado) {
        this.rodado = rodado;
    }
    
    //metodos
    @Override
    public String toString() {
        return "Bici{" + super.toString() + " rodado=" + rodado + '}';
    }
}
