package actividadesPracticasNro1.ejercicio9;

public class CuentaBancaria {
    //atributos
    private int saldo;
    
    //constructores
    public CuentaBancaria() {}
    
    //getters y setters
    public int getSaldo() {
        return saldo;
    }

    public void setSaldo(int saldo) {
        this.saldo = saldo;
    }
    
    //metodos
    public void depositar(int monto) {
        this.saldo += monto;
    }
    
    public void extraer(int monto) {
        this.saldo -= monto;
    }

}
