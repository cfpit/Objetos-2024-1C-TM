

package actividadesPracticasNro1.ejercicio10;


public class Test {
    public static void main(String[] args) {
        Empleado e = new Empleado("Juan Garcia", "1234",30, true, 500000);
        
        e.clasificar();
    }
}
