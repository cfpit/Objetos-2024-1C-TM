package estaticos;

public class Auto {
    //atributos
    private String marca;
    private static int velMax;
    
    //getters y setters
    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public static int getVelMax() {
        return velMax;
    }

    public static void setVelMax(int velMax) {
        Auto.velMax = velMax;
    }
    
    //metodos

    @Override
    public String toString() {
        return "Auto{" + "marca=" + marca + '}';
    }
    
    
}
