

package estaticos;


public class Test {
    public static void main(String[] args) {
        //creo un auto
        Auto a = new Auto();
        
        //inicializo el estado
        a.setMarca("Ford");
        //por ser estatico, no necesito crear objeto
        Auto.setVelMax(180);
        Auto.setVelMax(200);//puede cambiar el valor!
        
        //imprimo el valor de velocidad maxima de 
        //todos los autos
        System.out.println("Velocidad maxima = " + Auto.getVelMax());
        
        
        
    }
}
