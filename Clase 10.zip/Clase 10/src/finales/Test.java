package finales;

public class Test {
    public static void main(String[] args) {
        Auto a = new Auto();
        
        a.setMarca("Chevrolet");
        
        
        
//        a.VELMAX = 250;//no se puede cambiar la constante
        
        //muestro el valor de la constante
        System.out.println("Velocidad maxima = " + a.VELMAX);
    }
}
