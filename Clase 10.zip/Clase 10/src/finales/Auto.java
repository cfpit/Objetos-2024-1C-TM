package finales;

public class Auto {
    //atributos
    private String marca;
//    public static final int VELMAX = 200;
    public final int VELMAX = 200;
    
    //getters y setters
    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }
    
}
