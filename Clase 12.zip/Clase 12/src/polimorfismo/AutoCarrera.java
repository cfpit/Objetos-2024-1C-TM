package polimorfismo;

public class AutoCarrera extends Auto{
    //atributos
    private String tipoAleron;
    
    //constructores

    public AutoCarrera() {
    }

    public AutoCarrera(String tipoAleron, String marca, int velocidad) {
        super(marca, velocidad);
        this.setTipoAleron(tipoAleron);
    }
    
    
    //getters y setters
    public String getTipoAleron() {
            
        return tipoAleron;
    }

    public final void setTipoAleron(String tipoAleron) {
        this.tipoAleron = tipoAleron;
    }
    
    //metodos
    //sobrescribo el metodo acelerar heredado desde la clase padre(Auto)
    //la firma debe quedar igual pero cambia el cuerpo

    
    @Override
    public void acelerar() {
        this.velocidad += 50;
    }
    
    
    @Override
    public String toString() {
        return super.toString() + " tipoAleron=" + tipoAleron + '}';
    }
}












