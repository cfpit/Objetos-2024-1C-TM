

package polimorfismo;


public class Test {
    public static void main(String[] args) {
        //creo un auto comun y otro de carrera
        Auto a = new Auto("Ford", 0);
        AutoCarrera ac = new AutoCarrera("titanio", "Honda", 0);
        
        //acelero ambos vehiculos
        a.acelerar();//0->10
        ac.acelerar();//0->50 La hija se comporta diferente q su padre
        
        //muestro el estado de ambos vehiculos
        System.out.println(a);
        System.out.println("--------------------");
        System.out.println(ac);
    }
}
