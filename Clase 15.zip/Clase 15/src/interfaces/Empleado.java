/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package interfaces;

/**
 *
 * @author Aula 7 - Docente
 */
public interface Empleado{
    //contrato
//    public void metodo1();
//    public void metodo2();
//    public void metodo3();
    
    public void calcularSueldo();
}
