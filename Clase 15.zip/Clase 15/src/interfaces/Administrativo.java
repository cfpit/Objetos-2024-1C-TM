package interfaces;

public class Administrativo implements Empleado{
    //atributos
    private String nombre;
    private int valorHora;
    private int horasTrabajadas;
    
    //constructores
    public Administrativo() {}

    public Administrativo(String nombre, int valorHora, int horasTrabajadas) {
        this.setNombre(nombre);
        this.setValorHora(valorHora);
        this.setHorasTrabajadas(horasTrabajadas);
    }
    
    //getters y setters
    public String getNombre() {
        return nombre;
    }

    public final void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getValorHora() {
        return valorHora;
    }

    public final void setValorHora(int valorHora) {
        this.valorHora = valorHora;
    }

    public int getHorasTrabajadas() {
        return horasTrabajadas;
    }

    public final void setHorasTrabajadas(int horasTrabajadas) {
        this.horasTrabajadas = horasTrabajadas;
    }
    
    //metodos
    //implemento el metodo abstacto calcularSueldo 
    //de la interface Empleado

    @Override
    public void calcularSueldo() {
        System.out.println("Sueldo Administrativo = " + valorHora * horasTrabajadas);
    }
    

    @Override
    public String toString() {
        return "Administrativo{" + "nombre=" + nombre + ", valorHora=" + valorHora + ", horasTrabajadas=" + horasTrabajadas + '}';
    }
}
