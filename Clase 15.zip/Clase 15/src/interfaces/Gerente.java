package interfaces;

public class Gerente implements Empleado{
    //atributos
    private String nombre;
    private int sueldoBase;
    private int antiguedad;
    
    //constructores
    public Gerente() {}

    public Gerente(String nombre, int sueldoBase, int antiguedad) {
        this.setNombre(nombre);
        this.setSueldoBase(sueldoBase);
        this.setAntiguedad(antiguedad);
    }
    
    //getters y setters
    public String getNombre() {
        return nombre;
    }

    public final void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getSueldoBase() {
        return sueldoBase;
    }

    public final void setSueldoBase(int sueldoBase) {
        this.sueldoBase = sueldoBase;
    }

    public int getAntiguedad() {
        return antiguedad;
    }

    public final void setAntiguedad(int antiguedad) {
        this.antiguedad = antiguedad;
    }
    
    //metodos
    //implemento el metodo abstacto calcularSueldo 
    //de la interface Empleado

    @Override
    public void calcularSueldo() {
        System.out.println("Sueldo Gerente = " + (sueldoBase + sueldoBase * antiguedad * 0.1));
    }
    
    @Override
    public String toString() {
        return "Gerente{" + "nombre=" + nombre + ", sueldoBase=" + sueldoBase + ", antiguedad=" + antiguedad + '}';
    }
}
