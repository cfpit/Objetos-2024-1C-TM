package interfaces;

public class Test {
    public static void main(String[] args) {
        //creo 2 objetos
        Administrativo a = new Administrativo("Juan Perez", 10000, 100);
        Gerente g = new Gerente("Maria Garcia", 2000000, 5);
        
        //calculo del sueldo
        a.calcularSueldo();
        g.calcularSueldo();
    }
}
