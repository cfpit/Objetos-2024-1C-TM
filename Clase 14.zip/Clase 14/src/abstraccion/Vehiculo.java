package abstraccion;

public abstract class Vehiculo {
    //atributos
    protected int velocidad;

    //constructores
    public Vehiculo() {}

    public Vehiculo(int velocidad) {
        this.setVelocidad(velocidad);
    }
    
    //getters y setters
    public int getVelocidad() {
        return velocidad;
    }

    public final void setVelocidad(int velocidad) {
        this.velocidad = velocidad;
    }
    
    //metodos
    //metodo abstracto
    public abstract void acelerar();
//    public abstract void frenar();
//    public abstract void arrancar();
    
    

    @Override
    public String toString() {
        return " velocidad=" + velocidad;
    }

}
