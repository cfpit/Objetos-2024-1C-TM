

package abstraccion;


public class Test {
    public static void main(String[] args) {
           //no se puede instanciar objetos de una clase abstracta
//        Vehiculo v = new Vehiculo();

        //creo un avion y un bici
        Avion a = new Avion(100, 0);
        Bici b = new Bici(28, 0);
        
        //comportamiento
        a.acelerar();//0 --> 100
        b.acelerar();//0 --> 5
        
        //estado final
        System.out.println("Avion: " + a);
        System.out.println("---------------");
        System.out.println("Bici: " + b);
        
    }
}


