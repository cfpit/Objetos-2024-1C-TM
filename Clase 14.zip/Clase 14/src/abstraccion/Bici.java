package abstraccion;

public class Bici extends Vehiculo{
    //atributos
    private int rodado;
    
    //constructores
    public Bici() {}
    
    public Bici(int rodado, int velocidad) {
        super(velocidad);
        this.setRodado(rodado);
    }
    
    //getters y setters
    public int getRodado() {
        return rodado;
    }

    public final void setRodado(int rodado) {
        this.rodado = rodado;
    }
    
    //metodos
    //implemento el metodo abstracto acelerar del la clase padre(Vehiculo)
    @Override
    public void acelerar() {
        this.velocidad += 5;
    }

    @Override
    public String toString() {
        return  "rodado=" + rodado + super.toString();
    }

}
