package abstraccion;

public class Avion extends Vehiculo{
    //atributos
    private int cantidadDeAsientos;

    //constructores
    public Avion() {}

    public Avion(int cantidadDeAsientos, int velocidad) {
        super(velocidad);
        this.setCantidadDeAsientos(cantidadDeAsientos);
    }
    
    //getters y setters
    public int getCantidadDeAsientos() {
        return cantidadDeAsientos;
    }

    public final void setCantidadDeAsientos(int cantidadDeAsientos) {
        this.cantidadDeAsientos = cantidadDeAsientos;
    }
    
    //metodos
    //implemento el metodo abstracto de la clase padre(Vehiculo)
    @Override
    public void acelerar() {
        this.velocidad += 100;
    }

    @Override
    public String toString() {
        return "cantidadDeAsientos=" + cantidadDeAsientos + super.toString();
    }

}
