-- selecciono la base pubs 
use pubs;

-- veo las tablas de la base seleccionada
show tables;

-- veo la estructura de la tabla authors
describe authors;

-- queries
select * from authors;

-- listar nombre, telefono y ciudad de los autores q viven en California
-- y q no tengan contrato
select 	concat(au_fname,' ',au_lname) as autor
		, phone telefono
        , city ciudad
from	authors
where	state = 'ca' and contract = 0;

-- listar los titulos cuyo precio este entre 10 y 20 U$s
select	*
from	titles
where	price between 10 and 20;
-- where	not price between 10 and 20;

-- listar los empleados que ingresaron en los años 90 o 92 o 94
select	*
from	employee
where	year(hire_date) in (1990,1992,1994);

-- listar los autores cuyo nombre empiece con m, el 2do caracter sea cualquiera,
-- el tercer caracter sea una r y termine como sea.
select	*
from	authors
where	au_fname like 'm_r%';

-- listar la cantidad de titulos de cada categoria, ordenados x cantidad
-- de mayor a menor. No incluir las categorias sin definir y cuya cantidad 
-- de titulos pertenecientes sea mayor a 2
select		type categoria,
			count(title_id) 'cantidad de titulos'
from		titles
where		type <> ''
group by	type
having		count(title_id) > 2
order by	2 desc;

-- listar las editoriales q publicaron libros de cocina
select		p.*, t.type categoria
from		titles t
inner join	publishers p
on			p.pub_id = t.pub_id
where		t.type like '%cook%';

/*
	SQL 
		--> DDL
			--> CREATE
            --> ALTER
            --> DROP
            --> operan sobre objetos: bd, tablas, vistas, etc.
            
		--> DML
			--> INSERT
            --> UPDATE
            --> DELETE
            --> operan sobre registros
            
*/

create database colegio;

use colegio;

create table alumnos (nombre varchar(20), edad int);

insert into alumnos values
('Juan', 25),
('Maria', 30),
('Jose', 20),
('Carlos', 40);

select * from alumnos;










