create database colegio;

use colegio;

create table alumnos(nombre varchar(20), edad int);

insert into alumnos values 
('Juan', 25),('Jose', 30),('Carlos', 20),('Maria', 40);

select * from alumnos;

