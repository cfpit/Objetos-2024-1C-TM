

package abmc;


public class Alumno {

}
