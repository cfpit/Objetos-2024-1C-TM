

package actividadesPracticasNro1.ejercicio10;


public class Empleado {
    
    //atributos
    private String nombre;
    private String cedula;
    private int edad;
    private boolean casado;
    private double salario;
    
    //constructores
    public Empleado() {}

    public Empleado(String nombre, String cedula, int edad, boolean casado, double salario) {
        this.nombre = nombre;
        this.cedula = cedula;
        this.edad = edad;
        this.casado = casado;
        this.salario = salario;
    }
    
    //getters y setters

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public boolean isCasado() {
        return casado;
    }

    public void setCasado(boolean casado) {
        this.casado = casado;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }
    
    //metodos
    public void clasificar() {
        if (this.getEdad() < 21) 
        {
            imprimir(this,"Junior");
        } 
        else 
        {
            if (this.getEdad() >= 21 && this.getEdad() <= 34) 
            {
                imprimir(this,"Intermedio");
            } 
            else 
            {
                imprimir(this,"Senior");
            }
        }
    }
    
    
    public void imprimir(Empleado e,String experiencia) {
        System.out.println(e);
        System.out.println(" ---- " + experiencia);
    }

    @Override
    public String toString() {
        return "Empleado{" + "nombre=" + nombre + ", cedula=" + cedula + ", edad=" + edad + ", casado=" + casado + ", salario=" + salario + '}';
    }
    
    
    
    
    
    
    
    
    
     



}
