

package actividadesPracticasNro1.ejercicio6;


public class Gato {
//    nombre, raza, color y sus métodos: maullar(), caminar(), saltar(), jugar().
    
    //atributos
    private String nombre;
    private String raza;
    private String color;
    
    //constructores
    public Gato() {}

    public Gato(String nombre, String raza, String color) {
        this.nombre = nombre;
        this.raza = raza;
        this.color = color;
    }
    
    //getters y setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
    
    //metodos
    public void maullar() {
        System.out.println("miauuuuu");
    }
    
    public void caminar() {
        System.out.println("estoy caminando");
    }
    
    public void saltar() {
        System.out.println("estoy saltando");
    }
    
    public void jugar() {
        System.out.println("estoy jugando");
    }

    
}
