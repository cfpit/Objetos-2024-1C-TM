

package actividadesPracticasNro1.ejercicio9;


public class Test {
    public static void main(String[] args) {
        //creo la cuenta
        CuentaBancaria cb = new CuentaBancaria();
        
        //estado inicial
        cb.setSaldo(5000);
        
        //muestro el saldo
        System.out.println("Saldo = " + cb.getSaldo() + " $");
    }
}
