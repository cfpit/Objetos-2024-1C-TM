package streams.copiador;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Test {
    public static void main(String[] args) throws FileNotFoundException, IOException {
        try {
            File origen = new File("src\\streams\\copiador\\origen.txt");
            File destino = new File("src\\streams\\copiador\\destino.txt");
            
            BufferedReader lector = new BufferedReader(new FileReader(origen));
            BufferedWriter escritor = new BufferedWriter(new FileWriter(destino));

            //algoritmo de copia
            //variables auxiliares
            String lineaLeida = "";

            //bucle de copia
            while ((lineaLeida = lector.readLine()) != null) {
                escritor.write(lineaLeida);
                escritor.newLine();
            }

            //cierro los streams
            lector.close();
            escritor.close();
        } catch (FileNotFoundException e) {
            System.out.println("No se encontro el archivo");
        } catch (IOException e) {
            System.out.println("Error de copia");
        }
    }
}
