package streams.lector;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Test {
    public static void main(String[] args) throws FileNotFoundException, IOException {
        try {
            //creo un objeto File q tiene la ruta del archivo a leer
            File archivo = new File("src\\streams\\lector\\archivo.txt");

            //creo el stream de lectura
            BufferedReader lector = new BufferedReader(new FileReader(archivo));

            //algoritmo de lectura
            //variables auxiliares
            String lineaLeida = "";//almacena la linea leida por el stream
            boolean eof = false;//flag q indica si llego a fin de archivo

            //bucle de lectura
            //mientras no sea el fin de archivo...
            while (!eof) {
                lineaLeida = lector.readLine();
                
                if (lineaLeida == null) {
                    eof = true;
                } else {
                    System.out.println(lineaLeida);
                }
            }

            //cierro el stream
            lector.close();
        } catch (FileNotFoundException e) {
            System.out.println("No se encontro el archivo!!!");
        } catch (IOException e) {
            System.out.println("Error de lectura");
        } catch (Exception e) {
            System.out.println("Se produjo un Error");
        }
    }
}
