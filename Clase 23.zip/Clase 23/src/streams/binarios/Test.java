package streams.binarios;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Test {
    public static void main(String[] args) throws FileNotFoundException, IOException {
        File origen = new File("src\\streams\\binarios\\paisaje.jpg");
        File destino = new File("src\\streams\\binarios\\clon.jpg");
        
        FileInputStream lector = new FileInputStream(origen);
        FileOutputStream escritor = new FileOutputStream(destino);
        
        //algoritmo de copia
        int unByte;
        
        while ((unByte = lector.read()) != -1) {
            escritor.write(unByte);
        }
        
        //cierro los streams
        lector.close();
        escritor.close();
    }
}
