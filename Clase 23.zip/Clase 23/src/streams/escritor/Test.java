package streams.escritor;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Test {
    public static void main(String[] args) throws IOException {
        try {
            File archivo = new File("src\\streams\\escritor\\archivo.txt");
            
            BufferedWriter escritor = new BufferedWriter(new FileWriter(archivo));

            //preparo la info a escribir en el archivo
            String linea1 = "Hola!, soy la linea nro1";
            String linea2 = "Soy la linea nro2";
            String linea3 = "Y yo la linea nro3";

            //escribo en el archivo a traves del stream
            escritor.write(linea1);
            escritor.newLine();//salto de linea
            escritor.write(linea2);
            escritor.newLine();
            escritor.write(linea3);
            
            escritor.append("esto es un texto agregado");

            //cierro el stream
            escritor.close();
            
        } catch (IOException e) {
            System.out.println("Error de escritura");
        }
    }
}
