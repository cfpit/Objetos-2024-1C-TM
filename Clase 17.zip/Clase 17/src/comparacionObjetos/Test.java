package comparacionObjetos;

public class Test {
    public static void main(String[] args) {
//        String a  = new String("Juan");
//        String b  = new String("Pedro");
        
//        String a  = new String("Juan");
//        String b  = new String("Juan");
        
//        String a  = new String("Juan");
//        String b  = a;

//        Persona a = new Persona("Juan", 25);
//        Persona b = new Persona("Maria", 30);
        
        Persona a = new Persona("Juan", 25);
        Persona b = new Persona("Juan", 25);
        
        
        System.out.println("Comparacion de Referencias");
        if (a == b) {
            System.out.println("Los objetos tienen igual referencia");
        } else {
            System.out.println("Los objetos tienen distinta referencia");
        }
        
        
        System.out.println("----------------------------------------");
        
        System.out.println("Comparacion de Contenidos");
        if (a.equals(b)) {
            System.out.println("Los objetos tienen igual contenido");
        } else {
            System.out.println("Los objetos tienen distinto contenido");
        }
        
        System.out.println("Codigo de hash del objeto a: " + a.hashCode());
        System.out.println("Codigo de hash del objeto b: " + b.hashCode());
        
    }
}
