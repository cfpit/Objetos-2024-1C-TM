package comparacionObjetos;

import java.util.Objects;

public class Persona {
    private String nombre;
    private int edad;

    public Persona() {}

    public Persona(String nombre, int edad) {
        this.setNombre(nombre);
        this.setEdad(edad);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }
    
    //redefinimos equals y hashCode

//    @Override
//    public int hashCode() {
//        int hash = 5;
//        hash = 37 * hash + Objects.hashCode(this.nombre);
//        hash = 37 * hash + this.edad;
//        return hash;
//    }
    
    public int hashCode() {
       return Objects.hash(this.getNombre(), this.getEdad());
    }


    @Override
    public boolean equals(Object obj) {
        //casteo
        Persona unaPersona = (Persona)obj;
        
        //comparacion de contenidos
        if (this.getNombre().equals(unaPersona.getNombre()) && this.getEdad() == unaPersona.getEdad()) 
        {
            return true;
        } 
        else 
        {
            return false;
        }
    }
        

    @Override
    public String toString() {
        return "Persona{" + "nombre=" + nombre + ", edad=" + edad + '}';
    }
}
