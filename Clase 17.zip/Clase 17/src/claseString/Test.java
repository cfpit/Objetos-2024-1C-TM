package claseString;

import java.util.Arrays;

public class Test {

    public static void main(String[] args) {
        //length(): devuelve la longitud de la cadena.
        System.out.println("length()");
        String str = "Hola mundo!";
        int longitud = str.length(); // longitud = 11
        System.out.println("longitud = " + longitud);
        
        
        
        System.out.println("--------------------------------");


        //charAt(int index): devuelve el carácter en la posición especificada.
        System.out.println("charAt(int index)");
        String str2 = "Hola mundo!";
        char caracter = str2.charAt(3); // ch = ' '
        System.out.println("caracter = " + caracter);
        
        
        
        System.out.println("--------------------------------");
        
        
        //substring(int beginIndex, int endIndex): devuelve una subcadena de la 
        //cadena, comenzando en el índice beginIndex y terminando en el índice 
        //endIndex - 1.
        System.out.println("substring(int beginIndex, int endIndex)");
        String str3 = "Hola mundo!";
        String subStr = str3.substring(5, 10); // subStr = "mundo"
        System.out.println("subStr = " + subStr);


        
        System.out.println("--------------------------------");
        
        
        
        //indexOf(String str): devuelve el índice de la primera aparición de la 
        //cadena str dentro de la cadena actual.
        System.out.println("indexOf(String str)");
        String str4 = "Hola mundo!";
        int index = str4.indexOf("mundo"); // index = 5
        System.out.println("index = " + index);


        System.out.println("--------------------------------");
        
        
        //equals(Object obj): compara la cadena actual con el objeto obj para 
        //determinar si son iguales.
        System.out.println("equals(Object obj)");
        String str5 = "Hola mundo!";
        String str6 = "Hola mundo!";
        boolean iguales = str5.equals(str6); // iguales = true
        System.out.println("iguales = " + iguales);

        
        System.out.println("--------------------------------");
        
        
        //equalsIgnoreCase(String str): compara la cadena actual con la cadena 
        //str8 sin tener en cuenta las diferencias entre mayúsculas y minúsculas.
        System.out.println("equalsIgnoreCase(String str)");
        String str7 = "Hola mundo!";
        String str8 = "HOLA MUNDO!";
        boolean iguales2 = str7.equalsIgnoreCase(str8); //equal2=true
        System.out.println("iguales2 = " + iguales2);


        System.out.println("--------------------------------");
        
        
        //replace(char oldChar, char newChar): reemplaza todas las ocurrencias 
        //del carácter oldChar por el carácter newChar.
        System.out.println("replace(char oldChar, char newChar)");
        String str9 = "Hola mundo!";
        String str10 = str9.replace('o', 'x'); //newStr="Hxla mundx!"
        System.out.println("str10 = " + str10);


        System.out.println("--------------------------------");
        
        
        //toLowerCase(): convierte la cadena actual a minúsculas.
        System.out.println("toLowerCase()");
        String str11 = "Hola mundo!";
        String str12 = str11.toLowerCase(); // newStr = "hola mundo!"
        System.out.println("str12 = " + str12);


        System.out.println("--------------------------------");
        
        
        //toUpperCase(): convierte la cadena actual a mayúsculas.
        System.out.println("toUpperCase()");
        String str13 = "Hola mundo!";
        String str14 = str13.toUpperCase(); // newStr = "HOLA MUNDO!"
        System.out.println("str14 = " + str14);


        System.out.println("--------------------------------");
        
        
        //split(String regex): divide la cadena actual en varias subcadenas en 
        //función del patrón especificado por regex.
        System.out.println("split(String regex)");
        String str15 = "Hola,mundo!";
        String[] partes = str15.split(","); // partes = ["Hola", "mundo!"]
        System.out.println("partes = " + Arrays.asList(partes));

    }
}
