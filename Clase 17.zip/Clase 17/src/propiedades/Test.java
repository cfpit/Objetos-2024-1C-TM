package propiedades;

public class Test {
    public static void main(String[] args) {
        System.out.println("Propiedades del Sistema");
        System.out.println(System.getProperties());
        
        System.out.println("------------------------");
        
        System.out.println("Version de Java: "+ System.getProperty("java.version"));
        System.out.println("Sistema Operativo: "+ System.getProperty("os.name"));
        System.out.println("Version S.O.: "+ System.getProperty("os.version"));

            
        
        System.out.println("Garbagge Collector");
        System.gc();
    }
}











