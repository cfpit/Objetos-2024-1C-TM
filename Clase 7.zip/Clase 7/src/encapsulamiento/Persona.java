package encapsulamiento;

import java.util.Arrays;

public class Persona {

    //atributos
    private String nombre;
    private int edad;

    //constructores
    //vacio o por defecto
    public Persona() {
    }

    //sobrecargo el constructor
    public Persona(String nombre, int edad) {
        this.setNombre(nombre);
//        this.edad = edad;
        this.setEdad(edad);
    }

    //getters y setters
    public int getEdad() {
        return edad;
    }

    public String setEdad(int edad) {
        //regla de negocio
        if (edad >= 0 && edad <= 130) {
            this.edad = edad;
            return "Edad guardada";
        } else {
//            System.out.println("Edad no permitida");
            this.edad = 0;
            return "Edad no permitida";
        }
    }

    public String getNombre() {
        return nombre;
    }

    public String setNombre(String nombre) {
        //regla de negocio
        String[] nombres = {"Juan", "Pedro", "Maria", "Jose"};
        if (Arrays.asList(nombres).contains(nombre)) {
            this.nombre = nombre;
            return "Nombre guardado";
        } else {
//            System.out.println("Nombre no permitido");
            this.nombre = "";
            return "Nombre no permitido";
        }
    }

    //metodos
    public void saludar() {
        System.out.println("Hola, soy " + this.nombre + " !!");
    }

    public void cumplirAños() {
        this.edad++;
    }

    public String toString() {
        return "nombre=" + nombre + ", edad=" + edad;
    }
}
