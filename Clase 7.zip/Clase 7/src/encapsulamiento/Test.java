package encapsulamiento;

public class Test {
    public static void main(String[] args) {
        //creo un objeto
        Persona p = new Persona();
        Persona p1 = new Persona("Maria", 30);
        
        //inicializo el estado del objeto
//        p.nombre = "Juan";
        p.setNombre("Juan");
//        p.edad = 25;//no se puede por ser privado
        p.setEdad(90);
        
        //muestro el estado
        System.out.println(p);
        System.out.println("-------------------");
        System.out.println(p1);
    }
}









