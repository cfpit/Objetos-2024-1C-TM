package excepciones.ejemplo1;

public class Test {
    public static void main(String[] args) {
        try {
            System.out.println("Inicio");

//        String frase = "Hola Mundo!";
            String frase = null;
            System.out.println("Longitud: " + frase.length());
            
            System.out.println("Fin");
        } catch (NullPointerException e) {
            System.out.println("Error de puntero a nulo");
            e.printStackTrace();
        }
        
        System.out.println("Sigue el codigo...");
    }
}
