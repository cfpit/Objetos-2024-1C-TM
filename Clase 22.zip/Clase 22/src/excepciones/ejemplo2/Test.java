package excepciones.ejemplo2;

public class Test {
    public static void main(String[] args) {
        try {
            System.out.println("inicio");
            
            Integer.parseInt("esto va a dar error");
            
            String frase = null;
            System.out.println("Longitud: " + frase.length());
            
            System.out.println("fin");
        } catch (NumberFormatException e) {
            System.out.println("Error de parseo");
        } catch (NullPointerException e) {
            System.out.println("Error de puntero a nulo");
        } catch (Exception e) {
            System.out.println("Se produjo un Error");
        } finally{
            System.out.println("Tomando medidas correctivas...");
        } 
        
    }
}
