

package excepciones.usuario;


public class NoHayMasPasajesException extends Exception{
    private String nombreVuelo;
    private int asientosPedidos;

    public NoHayMasPasajesException() {}

    public NoHayMasPasajesException(String nombreVuelo, int asientosPedidos) {
        this.nombreVuelo = nombreVuelo;
        this.asientosPedidos = asientosPedidos;
    }

    public String getNombreVuelo() {
        return nombreVuelo;
    }

    public void setNombreVuelo(String nombreVuelo) {
        this.nombreVuelo = nombreVuelo;
    }

    public int getAsientosPedidos() {
        return asientosPedidos;
    }

    public void setAsientosPedidos(int asientosPedidos) {
        this.asientosPedidos = asientosPedidos;
    }
    
    //metodos
    public void mensajeDeError() {
        System.out.println("El vuelo " + this.nombreVuelo + 
                " no tiene " + this.asientosPedidos + " asientos disponibles");
    }

    @Override
    public String toString() {
        return "NoHayMasPasajesException{" + "nombreVuelo=" + nombreVuelo + ", asientosPedidos=" + asientosPedidos + '}';
    }
}
