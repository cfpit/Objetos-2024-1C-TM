package excepciones.usuario;

public class Test {
    public static void main(String[] args) throws NoHayMasPasajesException {
        try {
            //creo un vuelo
            Vuelo v = new Vuelo("ABC-123", 100);

            //venta de pasajes
            v.venderPasajes(35);
            v.venderPasajes(15);
            v.venderPasajes(20);
            v.venderPasajes(40);//esta linea lanza la excepcion
            v.venderPasajes(10);

            //estado del vuelo
            System.out.println(v);
        } catch (NoHayMasPasajesException e) {
            e.mensajeDeError();
        }
    }
}
