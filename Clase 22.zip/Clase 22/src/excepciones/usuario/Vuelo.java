package excepciones.usuario;

public class Vuelo {
    private String nombre;
    private int asientosDisponibles;

    public Vuelo() {}

    public Vuelo(String nombre, int asientosDisponibles) {
        this.nombre = nombre;
        this.asientosDisponibles = asientosDisponibles;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getAsientosDisponibles() {
        return asientosDisponibles;
    }

    public void setAsientosDisponibles(int asientosDisponibles) {
        this.asientosDisponibles = asientosDisponibles;
    }
    
    //metodos
    public void venderPasajes(int asientosPedidos) throws NoHayMasPasajesException {
        if (asientosPedidos > this.asientosDisponibles) {
            throw new NoHayMasPasajesException(this.nombre, asientosPedidos);
        } else {
            this.asientosDisponibles -= asientosPedidos;
        }
    }

    @Override
    public String toString() {
        return "Vuelo{" + "nombre=" + nombre + ", asientosDisponibles=" + asientosDisponibles + '}';
    }
}
