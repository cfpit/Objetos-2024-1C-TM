

package interfaz;


public class CajaDeAhorro {
    //atributos
    public int saldo;

    //constructores
    public CajaDeAhorro() {}
    
    //metodos
    public int informarSaldo() {
        return this.saldo;
    }
    
    public int depositar(int monto) {
        return this.saldo += monto;
    }
    
    public String extraer(int monto) {
        if (monto <= this.saldo) {
            this.saldo -= monto;
            return "Extraccion OK!";
        } else {
            return "Fondos insuficientes";
        }
    }
}
