
package ejercicio;

/**
 * 	La clase Vehiculo tiene 4 constructores:
 * 	
 * 		1 - Vehiculo sin precio ni radio el cual solo se puede dar en AutoClasico con los valores (String marca, String modelo, String color) el cual es el minimo requisito de un auto.
 * 		2 - Vehiculo con precio sin radio el cual solo se puede dar en AutoClasico con los valores (String marca, String modelo, String color, double precio)
 * 		2 - Vehiculo sin precio con radio con los valores (String marca, String modelo, String color, String nombreRadio)
 * 		4 - Vehiculo con precio con radio con los valores (String marca, String modelo, String color, String nombreRadio, double precio)
 * 	
 */
public abstract class Vehiculo {
	private String marca;
	private String modelo;
	private String color;
	private double precio;
	protected Radio radio;

	// Vehiculo sin precio ni radio el cual solo se puede dar en AutoClasico
	public Vehiculo(String marca, String modelo, String color) {
            this.marca = marca;
            this.modelo = modelo;
            this.color = color;
	}

	// Vehiculo con precio sin radio el cual solo se puede dar en AutoClasico
	public Vehiculo(String marca, String modelo, String color, double precio) {
            this.marca = marca;
            this.modelo = modelo;
            this.color = color;
            this.precio = precio;
	}

	// Vehiculo sin precio pero con radio 
	public Vehiculo(String marca, String modelo, String color, Radio radio) {
		this.marca = marca;
		this.modelo = modelo;
		this.color = color;
		this.radio = radio;
	}
        
        
        // Vehiculo con precio y con radio 
        public Vehiculo(String marca, String modelo, String color, double precio, Radio radio) {
            this.marca = marca;
            this.modelo = modelo;
            this.color = color;
            this.precio = precio;
            this.radio = radio;
        }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public Radio getRadio() {
        return radio;
    }

    public void setRadio(Radio radio) {
        this.radio = radio;
    }
    
    //metodos
    public abstract void agregarRadio(Radio radio);
    
    public abstract void cambiarRadio(Radio radio);
    
    @Override
    public String toString() {
        return "Auto [color=" + color + ", marca=" + marca + ", modelo=" + modelo + ", precio=" + precio + ", radio=" + radio + "]";
    }

}
