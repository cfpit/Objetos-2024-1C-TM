
package ejercicio;

public class AutoClasico extends Vehiculo {

    
    
    // AutoClasico sin precio ni radio
    public AutoClasico(String marca, String modelo, String color) {
        super(marca, modelo, color);
    }


    // AutoClasico sin precio con radio
    public AutoClasico(String marca, String modelo, String color, Radio radio) {
            super(marca, modelo, color, radio);
    }

    // AutoClasico con precio sin radio
    public AutoClasico(String marca, String modelo, String color, double precio) {
            super(marca, modelo, color, precio);
    }

    // AutoClasico con precio y con radio
    public AutoClasico(String marca, String modelo, String color, double precio, Radio radio) {
        super(marca, modelo, color, precio, radio);
    }
    
    @Override
    public void agregarRadio(Radio radio) {
        this.radio = new Radio(radio.getMarca(), radio.getPotencia());
    }
        
    @Override
    public void cambiarRadio(Radio radio) {
        this.setRadio(radio);
    }

    @Override
    public String toString() {
        return "AutoClasico{" + super.toString() + '}';
    }

}
