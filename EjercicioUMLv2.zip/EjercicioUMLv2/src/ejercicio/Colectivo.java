
package ejercicio;

public final class Colectivo extends Vehiculo {

    // Colectivo con precio sin radio
    public Colectivo(String marca, String modelo, String color) {
        super(marca, modelo, color);
    }

    // Colectivo con precio y con radio
    public Colectivo(String marca, String modelo, String color, double precio) {
        super(marca, modelo, color, precio);
    }

    // Colectivo con precio sin radio
    public Colectivo(String marca, String modelo, String color, Radio radio) {
        super(marca, modelo, color, radio);
    }

    // Colectivo con precio y con radio
    public Colectivo(String marca, String modelo, String color, double precio, Radio radio) {
        super(marca, modelo, color, precio, radio);
    }
    
    @Override
    public void agregarRadio(Radio radio) {
        this.radio = new Radio(radio.getMarca(), radio.getPotencia());
    }
    
    @Override
    public void cambiarRadio(Radio radio) {
        this.setRadio(radio);
    }

    @Override
    public String toString() {
        return "Colectivo{" + super.toString() + '}';
    }

}
