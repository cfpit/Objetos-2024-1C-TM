
package ejercicio;

/**
 * La clase AutoNuevo es una subclase de la clase Vehiculo
 */
public class AutoNuevo extends Vehiculo {

    //AutoNuevo siempre tiene radio y se puede cambiar
    //AutoNuevo con precio y radio
    public AutoNuevo(String marca, String modelo, String color, Radio radio) {
        super(marca, modelo, color, radio);
    }

    //AutoNuevo sin precio pero con radio
    public AutoNuevo(String marca, String modelo, String color, double precio, Radio radio) {
        super(marca, modelo, color, precio, radio);
    }

//    public Radio getRadio() {
//        return radio;
//    }
//
//    public void setRadio(Radio radio) {
//        this.radio = radio;
//    }
    
    
    public void cambiarRadio(Radio radio) {
        this.setRadio(radio);
    }
    
    public void agregarRadio(Radio radio) {
        this.radio = new Radio(radio.getMarca(), radio.getPotencia());
    }

    @Override
    public String toString() {
        return "AutoNuevo{" + super.toString() + " }";
    }
    
    

	
}