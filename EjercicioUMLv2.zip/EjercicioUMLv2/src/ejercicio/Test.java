
package ejercicio;

public class Test {
    public static void main(String[] args) {
        System.out.println("-----------------------------------------------------------------------------------------------------------------------");
		System.out.println("Actividad 1");
		System.out.println("-----------------------------------------------------------------------------------------------------------------------");

		System.out.println("1 - Auto clasico sin radio, sin precio");
		AutoClasico ac1 = new AutoClasico("Porsche", "911", "Azul");
		System.out.println(ac1);

		System.out.println("-----------------------------------------------------------------------------------------------------------------------");

		System.out.println("2 - Auto clasico sin radio, con precio");
		AutoClasico ac2 = new AutoClasico("Mercedes", "300", "Rojo", 50000);
		System.out.println(ac2);

		System.out.println("-----------------------------------------------------------------------------------------------------------------------");

		System.out.println("3 - Auto clasico con radio, sin precio");
                Radio r1 = new Radio("Pioneer", "300W");
		AutoClasico ac3 = new AutoClasico("Volkswagen", "Beetle", "Bordo", r1);
		System.out.println(ac3);

		System.out.println("-----------------------------------------------------------------------------------------------------------------------");

		System.out.println("4 - Auto clasico con radio y con precio");
                Radio r2 = new Radio("Sony", "400W");
		AutoClasico ac4 = new AutoClasico("Callidac", "Fleetwood", "Rojo", 70000, r2);
		System.out.println(ac4);

		System.out.println("-----------------------------------------------------------------------------------------------------------------------");

		System.out.println("5.2 - Agregar radio a auto clasico");
		ac1.setRadio(r2);
		System.out.println(ac1);
    }
}
