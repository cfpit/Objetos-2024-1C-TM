package listas;

import java.util.ArrayList;
import java.util.Iterator;

public class Test {
    public static void main(String[] args) {
        //creo una coleccion de tipo Lista
        ArrayList<Persona> lista = new ArrayList<Persona>();
        
        //creo objetos de la clase Persona
        Persona p1 = new Persona("Juan", 25);
        Persona p2 = new Persona("Carlos", 30);
        Persona p3 = new Persona("Jose", 40);
        Persona p4 = new Persona("Maria", 20);
        
        //guardo en la coleccion los objetos
        lista.add(p1);
        lista.add(p2);
        lista.add(p3);
        lista.add(p4);
        
        System.out.println("Longitud: " + lista.size());
        
        System.out.println("Agrego objeto sin referencia");
        lista.add(new Persona("Luis", 45));
        
        System.out.println("Contenido: " + lista);
        
        System.out.println("Agrego objeto en el indice 2: ");
        Persona p6 = new Persona("Pedro", 30);
        lista.add(2, p6);
        
        System.out.println("Nuevo Contenido: " + lista);
        
//        System.out.println("Elimino a Carlos");
//        System.out.println(lista.remove(1));//nombre=Carlos, edad=30
//        System.out.println(lista.remove(1).getNombre());//Carlos
        
            System.out.println(lista.get(1).getNombre());//Carlos
            
            p2.setNombre("Charly");
            
            System.out.println("Nuevo Contenido: " + lista);
            
            System.out.println("---------------------------");
            
            System.out.println("Longitud: " + lista.size());
            
            System.out.println("Recorro la lista con for");
            
            System.out.println("Personas mayores a 30 años");
            for (int i = 0; i < lista.size(); i++) {
                Persona unaPersona = lista.get(i);
                if (unaPersona.getEdad() > 30) {
                    System.out.println(unaPersona.getNombre());
                }
            }
            
            System.out.println("Recorro la lista con foreach");
            for (Persona unaPersona : lista) {
                if (unaPersona.getEdad() > 30) {
                    System.out.println(unaPersona.getNombre());
                }
            }
            
            System.out.println("Recorro la lista con Iterator");
            //creo un iterador para recorrer la coleccion
            Iterator it = lista.iterator();
            
            //recorro la coleccion
            while (it.hasNext()) {
            Persona unaPersona = (Persona)it.next();
            if (unaPersona.getEdad() > 30) {
                    System.out.println(unaPersona.getNombre());
                }
            }
            
    }
}













