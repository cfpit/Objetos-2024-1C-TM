package listas;

public class Persona {
    //atributos
    private String nombre;
    private int edad;
    
    //constructores
    public Persona() {}

    public Persona(String nombre, int edad) {
        this.setEdad(edad);
        this.setNombre(nombre);
    }
    
    //getters
    public String getNombre() {
        return nombre;
    }

    public final void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public final void setEdad(int edad) {
        this.edad = edad;
    }
    
    //metodos
    @Override
    public String toString() {
        return "nombre=" + nombre + ", edad=" + edad;
    }
    
}
