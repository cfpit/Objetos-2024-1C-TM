package set;

public class Persona implements Comparable<Persona>{
    //atributos
    private String nombre;
    private int edad;
    
    //constructores
    public Persona() {}

    public Persona(String nombre, int edad) {
        this.setEdad(edad);
        this.setNombre(nombre);
    }
    
    //getters
    public String getNombre() {
        return nombre;
    }

    public final void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public final void setEdad(int edad) {
        this.edad = edad;
    }

    //metodos
    //implemento el metodo compareTo

    @Override
    public int compareTo(Persona o) {
//        return this.getNombre().compareTo(o.getNombre());
            return Integer.compare(this.getEdad(), o.getEdad());
    }
    
    
    @Override
    public String toString() {
        return "nombre=" + nombre + ", edad=" + edad;
    }
    
}
