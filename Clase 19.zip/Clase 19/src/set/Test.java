package set;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.TreeSet;

public class Test {
    public static void main(String[] args) {
        //creo la coleccion de tipo Set
//        HashSet<String> coleccion = new HashSet();//desordena el ingreso
//        LinkedHashSet<String> coleccion = new LinkedHashSet();//ordena segun el ingreso
        TreeSet<String> coleccion = new TreeSet();//orden alfabetico de los valores
        
        //agrego objetos de tipo String en la coleccion
        coleccion.add("Juan");
        coleccion.add("Carlos");
        coleccion.add("Jose");
        coleccion.add("Maria");
        
        //evita la duplicidad de objetos
        coleccion.add("Jose");
        
        
        System.out.println("Contenido: " + coleccion);
    }
}
