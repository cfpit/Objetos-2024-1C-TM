package set;

import java.util.TreeSet;

public class Test2 {
    public static void main(String[] args) {
        //creo la coleccion
        TreeSet<Persona> coleccion = new TreeSet();
        
        //creo los objetos de la clase Persona
        Persona p1 = new Persona("Juan", 25);
        Persona p2 = new Persona("Carlos", 30);
        Persona p3 = new Persona("Jose", 40);
        Persona p4 = new Persona("Maria", 20);
        
        //agrego los objetos en la coleccion
        coleccion.add(p1);
        coleccion.add(p2);
        coleccion.add(p3);
        coleccion.add(p4);
        
        System.out.println("Contenido: " + coleccion);
    }
}
