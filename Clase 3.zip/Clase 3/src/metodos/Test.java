package metodos;

public class Test {
    public static void main(String[] args) {
        //creo una caja
        CajaDeAhorro cda = new CajaDeAhorro();
        CajaDeAhorro cda2 = new CajaDeAhorro();
        
        //estado inicial
        cda.saldo = 5000;
        cda.moneda = "U$s";

        //comportamiento
        cda.depositar(1500);
        
        System.out.println(cda.extraer(7000));
        
        
        cda.informarSaldo();
        System.out.println("---------------");
        cda2.informarSaldo();
        
    }
}
