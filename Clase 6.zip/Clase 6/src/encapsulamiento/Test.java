package encapsulamiento;

public class Test {
    public static void main(String[] args) {
        //creo un objeto
        Persona p = new Persona();
        
        //inicializo el estado del objeto
        p.nombre = "Juan";
//        p.edad = 25;//no se puede por ser privado
        p.setEdad(90);
        
        //muestro el estado
        System.out.println(p);
    }
}
