package encapsulamiento;



public class Persona{
    //atributos
    public String nombre;
    private int edad;
    
    //constructores
    //vacio o por defecto
    public Persona() {}
    
    //sobrecargo el constructor

    public Persona(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
    }
    
    //getters y setters
    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        //regla de negocio
        if (edad >= 0 && edad <= 130) {
            this.edad = edad;
        } else {
            System.out.println("Edad no permitida");
        }
    }
    
    
    //metodos
    public void saludar() {
        System.out.println("Hola, soy " + this.nombre + " !!");
    }
    
    public void cumplirAños() {
        this.edad ++;
    }

    @Override
    public String toString() {
        return "nombre=" + nombre + ", edad=" + edad;
    }
}
