package constructores;

public class Persona{
    //atributos
    public String nombre;
    public int edad;
    
    //constructores
    //vacio o por defecto
    public Persona() {}
    
    //sobrecargo el constructor

    public Persona(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
    }
    
    //metodos
    public void saludar() {
        System.out.println("Hola, soy " + this.nombre + " !!");
    }
    
    public void cumplirAños() {
        this.edad ++;
    }

    @Override
    public String toString() {
        return "nombre=" + nombre + ", edad=" + edad;
    }
}
