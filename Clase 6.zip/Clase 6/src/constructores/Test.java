package constructores;

public class Test {
    public static void main(String[] args) {
        //creo 2 objetos
        Persona p = new Persona();
        
        Persona pb = new Persona("Juan Perez", 250);
        
        //comportamiento
        pb.saludar();
        
        pb.cumplirAños();//25 --> 26
        
        //muestro el estado de ambos objetos
        System.out.println(p.toString());//nombre=null edad=0
        System.out.println("-----------------");
        System.out.println(pb);//nombre=Juan Perez edad=26
        
    }
}
