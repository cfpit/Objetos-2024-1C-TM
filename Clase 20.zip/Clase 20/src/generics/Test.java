package generics;

public class Test {
    public static void main(String[] args) {
        //creo un objeto de la clase Generica
        Generica g = new Generica();
        
//        System.out.println("Objetos de la clase String");
//        
//        g.agregar("Juan");
//        g.agregar("Jose");
//        g.agregar("Carlos");
//        g.agregar("Maria");
//        
//        System.out.println("Primer Nombre: " + g.obtener(0));
//        
//        System.out.println("Elimino al 2do: " + g.eliminar("Jose"));        
//        
//        System.out.println("Contenido: " + g.lista);
        
        
//        System.out.println("Numeros");
//        
//        g.agregar(10);
//        g.agregar(40);
//        g.agregar(30);
//        g.agregar(25);
//        
//        System.out.println("Primer Numero: " + g.obtener(0));
//        
//        System.out.println("Elimino al 2do: " + g.eliminar(40));        
//        
//        System.out.println("Contenido: " + g.lista);
        
        
        System.out.println("Objetos de la clase Persona");
        
        g.agregar(new Persona("Juan", 25));
        g.agregar(new Persona("Jose", 40));
        g.agregar(new Persona("Carlos", 30));
        g.agregar(new Persona("Maria", 20));
        
        
        System.out.println("Primera Persona: " + g.obtener(0));
        
        System.out.println("Contenido: " + g.lista);
        
        
    }
}
