package generics;

import java.util.ArrayList;

public class Generica <T>{
    ArrayList<T> lista = new ArrayList();
    
    //metodos delegados
    public T obtener(int index) {
        return lista.get(index);
    }

    public boolean agregar(T e) {
        return lista.add(e);
    }

    public boolean eliminar(Object o) {
        return lista.remove(o);
    }
    
    
    
}
