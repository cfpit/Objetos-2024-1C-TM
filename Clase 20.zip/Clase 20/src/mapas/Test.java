package mapas;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.TreeMap;

public class Test {
    public static void main(String[] args) {
        //creo el mapa
//        HashMap<String,String> mapa = new HashMap();//desordena las claves
//        LinkedHashMap<String,String> mapa = new LinkedHashMap();//ordena las claves segun ingreso
        TreeMap<String,String> mapa = new TreeMap();//orden alfabetico de las claves
        
        
        //agrego elementos al mapa
        mapa.put("rojo", "red");
        mapa.put("verde", "green");
        mapa.put("azul", "blue");
        mapa.put("blanco", "white");
        
        System.out.println("Contenido: " + mapa);
        
        System.out.println("Claves: " + mapa.keySet());
        
        System.out.println("Claves: " + mapa.values());
        
        System.out.println("Traduccion de rojo: " + mapa.get("rojo"));
        
        System.out.println("Traduccion de amarillo: " + mapa.getOrDefault("amarillo", "No se encontro"));
        
        
        
        
        
        
    }
}
